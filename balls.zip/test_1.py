import pygame
from random import randrange as rnd

WIDTH, HEIGHT = 1200, 800
fps = 60
paddle_w = 330
paddle_h = 35
paddle_speed = 15
paddle = pygame.Rect(WIDTH // 2 - paddle_w // 2, HEIGHT - paddle_h - 10, paddle_w, paddle_h)
pygame.display.set_caption("bolls arkada mini")

ball_radius = 20
ball_speed = 6
ball_rect = int(ball_radius * 2 ** 0.5)
ball = pygame.Rect(rnd(ball_rect, WIDTH - ball_rect), HEIGHT // 2, ball_rect, ball_rect)
dx, dy = 1, -1

block_list = [pygame.Rect(10 + 92 * i, 10 + 40 * j, 80, 30) for i in range(13) for j in range(10)]
color_list = [(rnd(30, 256), rnd(30, 256), rnd(30, 256)) for i in range(13) for j in range(10)]


pygame.init()
sc = pygame.display.set_mode((WIDTH, HEIGHT))
clock = pygame.time.Clock()

img = pygame.image.load('2.jpg').convert()
win = 0


def detect_collision(dx, dy, ball, rect):
    if dx > 0:
        delta_x = ball.right - rect.left
    else:
        delta_x = rect.right - ball.left
    if dy > 0:
        delta_y = ball.bottom - rect.top
    else:
        delta_y = rect.bottom - ball.top

    if abs(delta_x - delta_y) < 10:
        dx, dy = -dx, -dy
    elif delta_x > delta_y:
        dy = -dy
    elif delta_y > delta_x:
        dx = -dx
    return dx, dy


while True:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            exit()
    sc.blit(img, (0, 0))

    [pygame.draw.rect(sc, color_list[color], block) for color, block in enumerate(block_list)]
    pygame.draw.rect(sc, pygame.Color('darkorange'), paddle, 10)
    pygame.draw.circle(sc, pygame.Color('white'), ball.center, ball_radius)

    ball.x += ball_speed * dx
    ball.y += ball_speed * dy

    if ball.centerx < ball_radius or ball.centerx > WIDTH - ball_radius:
        dx = -dx

    if ball.centery < ball_radius:
        dy = -dy

    if ball.colliderect(paddle) and dy > 0:
        dx, dy = detect_collision(dx, dy, ball, paddle)

    hit_index = ball.collidelist(block_list)
    if hit_index != -1:
        hit_rect = block_list.pop(hit_index)
        hit_color = color_list.pop(hit_index)
        dx, dy = detect_collision(dx, dy, ball, hit_rect)

        hit_rect.inflate_ip(ball.width * 3, ball.height * 3)
        pygame.draw.rect(sc, hit_color, hit_rect)
        fps += 0.5
        win += 1

    if ball.bottom > HEIGHT:

        font = pygame.font.Font(None, 200)
        fonts = pygame.font.Font(None, 80)
        text = font.render(f"очки : {win}", True, (0, 0, 255))
        sc.blit(text, (300, 20))
        dx = 0
        dy = 0
        texts = fonts.render(f"в следующий раз ты пройдёшь", True, (0, 0, 255))
        sc.blit(texts, (200, 220))

    elif not len(block_list):
        font = pygame.font.Font(None, 200)
        fonts = pygame.font.Font(None, 100)
        text = font.render(f"очки : {win}", True, (0, 0, 255))
        texts = fonts.render(f"молодец ты прошёл игру!", True, (0, 0, 255))
        sc.blit(texts, (200, 220))
        sc.blit(text, (300, 20))
        dx = 0
        dy = 0
        print('WIN!!!')


    key = pygame.key.get_pressed()
    if key[pygame.K_LEFT] and paddle.left > 0:
        paddle.left -= paddle_speed
    if key[pygame.K_RIGHT] and paddle.right < WIDTH:
        paddle.right += paddle_speed

    pygame.display.flip()
    clock.tick(fps)